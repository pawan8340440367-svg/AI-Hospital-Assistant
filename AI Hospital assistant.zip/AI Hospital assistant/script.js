document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const otpGroup = document.getElementById('otpGroup');
    const actionBtn = document.getElementById('actionBtn');

    let isOtpSent = false;

    loginForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        // 1. अगर OTP अभी तक नहीं भेजा गया है, तो OTP भेजने का प्रोसेस चलेगा
        if (!isOtpSent) {
            const userIdentifier = document.querySelector('#userIdentifierGroup input').value.trim();

            if (!userIdentifier) {
                alert('कृपया अपना मोबाइल नंबर दर्ज करें!');
                return;
            }

            actionBtn.innerText = 'Sending OTP...';
            actionBtn.disabled = true;

            try {
                // हमारे Node.js backend server को कॉल करना
                const response = await fetch('http://localhost:3000/send-sms', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ phone: userIdentifier })
                });

                const data = await response.json();

                if (data.success) {
                    alert('OTP आपके मोबाइल नंबर पर सफलतापूर्वक भेज दिया गया है!');
                    
                    // OTP वाला बॉक्स दिखाएँ
                    otpGroup.style.display = 'block';
                    actionBtn.innerText = 'Verify OTP & Login';
                    actionBtn.disabled = false;
                    isOtpSent = true;
                } else {
                    alert('समस्या: ' + data.message);
                    actionBtn.innerText = 'Send OTP';
                    actionBtn.disabled = false;
                }
            } catch (error) {
                console.error('Error:', error);
                alert('सर्वर से कनेक्ट नहीं हो पा रहा है। सुनिश्चित करें कि Terminal में server.js चल रहा है!');
                actionBtn.innerText = 'Send OTP';
                actionBtn.disabled = false;
            }
        } 
        // 2. अगर OTP भेजा जा चुका है, तो Login / Welcome Page पर ले जाने का प्रोसेस
        else {
            const otpInput = document.getElementById('otp').value.trim();

            if (otpInput === '123456') { // Fast2SMS में हमने 123456 भेजा था
                alert('Login सफल हुआ!');
                window.location.href = 'welcome.html';
            } else {
                alert('गलत OTP! कृपया सही OTP दर्ज करें।');
            }
        }
    });
});