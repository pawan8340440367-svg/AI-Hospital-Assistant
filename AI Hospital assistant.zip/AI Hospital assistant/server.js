const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// आपकी नई Fast2SMS API Key
const API_KEY = 'Thz3zDygO0YrNBkwN2Cc25e4gO5wEZTSEV4ui39NOADvK06ZPB6fkOdc5Xl4';

app.post('/send-sms', async (req, res) => {
    const { phone } = req.body;

    if (!phone) {
        return res.status(400).json({ success: false, message: 'फ़ोन नंबर ज़रूरी है' });
    }

    try {
        const response = await axios({
            method: 'post',
            url: 'https://www.fast2sms.com/dev/bulkV2',
            headers: {
                'authorization': API_KEY.trim(),
                'Content-Type': 'application/json'
            },
            data: {
                'route': 'otp',
                'variables_values': '123456',
                'numbers': phone
            }
        });

        console.log('Fast2SMS Response:', response.data);

        if (response.data.return) {
            res.json({ success: true, message: 'SMS सफलतापूर्वक भेज दिया गया!', data: response.data });
        } else {
            res.status(400).json({ success: false, message: response.data.message[0] || 'SMS नहीं भेजा जा सका' });
        }

    } catch (error) {
        console.error('Fast2SMS Error Details:', error.response ? error.response.data : error.message);
        res.status(500).json({ success: false, message: 'SMS भेजने में विफलता हुई' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});