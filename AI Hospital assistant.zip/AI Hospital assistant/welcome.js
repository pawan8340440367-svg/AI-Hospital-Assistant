// Health Database (Common Symptoms & Solutions)
const healthKnowledgeBase = [
    {
        keywords: ['fever', 'bukhar', 'headache', 'sir dard'],
        specialist: 'General Physician',
        tests: ['CBC (Complete Blood Count)', 'Dengue/Malaria Test (agar 2-3 din se zyada ho)'],
        precautions: ['Paryaapt aaram karein aur paani/fluids zyada se zyada lein.', 'Patti (Cold Compress) maathe par rakhein.'],
        medicinesNote: 'Paracetamol (Doctor ki salah se lein).'
    },
    {
        keywords: ['kidney', 'gurda', 'stone', 'pathri'],
        specialist: 'Nephrologist / Urologist',
        tests: ['KFT (Kidney Function Test)', 'Urine Routine Test', 'Ultrasound (Abdomen)'],
        precautions: ['Din mein kam se kam 3-4 litre paani piyen.', 'Namak aur over-the-counter painkillers ka sewan kam karein.'],
        medicinesNote: 'Bina Doctor ki salah ke koi heavy painkiller mat lein.'
    },
    {
        keywords: ['stomach', 'pet dard', 'gas', 'acidity', 'indigestion'],
        specialist: 'Gastroenterologist / General Physician',
        tests: ['Ultrasound (Abdomen)', 'Endoscopy (agar dikkat purani ho)'],
        precautions: ['Masaaledar aur bahar ka khana mat khayein.', 'Ek baar mein zyada khane ke bajaye thoda-thoda khayein.'],
        medicinesNote: 'Antacid ya Gas ki dawai doctor ke sujhaav par lein.'
    }
];

// Chat Form Submit Handler
chatForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const messageText = userInput.value.trim();

    if (messageText !== "") {
        // 1. User Message Display
        const userDiv = document.createElement('div');
        userDiv.classList.add('message', 'user-message');
        userDiv.innerText = messageText;
        chatContainer.appendChild(userDiv);

        userInput.value = "";
        chatContainer.scrollTop = chatContainer.scrollHeight;

        // 2. Dynamic Medical AI Response Logic
        setTimeout(() => {
            const aiDiv = document.createElement('div');
            aiDiv.classList.add('message', 'ai-message');

            const lowerMsg = messageText.toLowerCase();
            
            // Search in Knowledge Base
            let matchedData = healthKnowledgeBase.find(item => 
                item.keywords.some(keyword => lowerMsg.includes(keyword))
            );

            let aiResponse = "";

            if (matchedData) {
                // Structured Output for Recognized Symptoms
                aiResponse = `
                    <b> Aapki Health Query ka Complete Solution:</b><br><br>
                    👨‍⚕️ <b>Kis Doctor se milein:</b> ${matchedData.specialist}<br><br>
                    🧪 <b>Recommended Tests:</b><br>
                    ${matchedData.tests.map(test => `- ${test}`).join('<br>')}<br><br>
                    ⚠️ <b>Primary Care & Precautions:</b><br>
                    ${matchedData.precautions.map(p => `- ${p}`).join('<br>')}<br><br>
                    💡 <b>Important Note:</b> ${matchedData.medicinesNote}<br><br>
                    <i> Note: Agar dikkat zyada badh rahi ho ya emergency ho, toh turant paas ke hospital ke Emergency Ward mein jayein.</i>
                `;
            } else {
                // Default Structured Response for Any General Health Question
                aiResponse = `
                    <b> Health Query Response:</b><br><br>
                    Aapne jo samasya batayi hai ("${messageText}"), uske liye ye primary steps follow karein:<br><br>
                    1. 👨‍⚕️ <b>Doctor Consultation:</b> Sabse pehle ek <b>General Physician</b> se consult karein taaki sahi diagnosis ho sake.<br>
                    2. 🧪 <b>Basic Tests:</b> Sahi karan janne ke liye Blood Test ya Routine Checkup karwayen.<br>
                    3. 📄 <b>Reports Share Karein:</b> Agar aapke paas koi purani report ya prescription hai, toh aap niche <b>'+'</b> button se yahan upload kar sakte hain.<br><br>
                    <i> Disclaimer: Ye AI sirf guidance ke liye hai, final treatment doctor ki salah par hi lein.</i>
                `;
            }

            aiDiv.innerHTML = aiResponse;
            chatContainer.appendChild(aiDiv);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }, 800);
    }
});